import Foundation
// MARK: SIRKET SIMULASYONU

var employees : [String] = [] // calisanlar eklenecek
var salaries : [Int] = [] // calisan maaslari eklenecek
var sum : Int = 0 // salaries array'in toplam degerini tasiyacak.

protocol CompanyInfo { // sirketin constant temel bilgilerinin girisi yapilir.
    var companyName : String { set get }
    var establishment : Int { set get }
}

protocol Payable { // sirketin odeme yapma / para cikis modellerini tasir.
    var budget : Int { get set } // sirket butcesidir.
    mutating func salaryPayment() -> Int //maas odemelerini yapan func
    mutating func addPayment(pay : Int) -> Int // ekstra odemeler icin kullanilan func
    mutating func addBudget(forIncrement add : Int) -> Int // gelir ekleme

}
protocol Employeable { // sirkete eleman ekle/cikar func sahiptir.
    var personel : [String] { get set }
    mutating func addPersonel(add : String) -> ()
    mutating func disPersonel() -> ()
}

struct Company : CompanyInfo, Payable, Employeable { // sirkete info, pay, employee protocolleri comform edildi.
    var personel: [String] //personeller icin array
    
    mutating func addPersonel(add : String) {
        personel.append(add) // personel eklenirse array ile alinir.
    }
    
    mutating func disPersonel() { // personel cikarilirsa arrayden cikarilir.
        personel.removeLast()
    }
    
    
    var companyName: String = "Atalan Group"
    var establishment: Int = 1997
    
    var salaries : [Int]

    var budget : Int = 1000000 // bi milyon bütcemiz var.
    var salarySum : Int


    mutating func addPayment(pay : Int) -> Int {
        if pay <= budget { //odeme butceden kucukse
            budget = budget - pay // odeme yapilir
            return budget // ve butcenin son hali donulur.
        } else {
            print("yeterli butce bulunmamaktadir")
            return budget //yeterli butce yoksa odeme yapilmaz.
        }

    }
    
    mutating func addBudget(forIncrement add: Int) -> Int {
            budget += add // butceye gelir girisi
            return budget
    }

    mutating func salaryPayment() -> Int {
        if salarySum <= budget { //maas odemeleri, butceden kucukse
            budget = budget - salarySum // odeme yapilir.
            return budget // butceden dusulur.
        } else {
            print("yeterli butce bulunmamaktadir")
            return budget // yeterli butce yoksa odeme yapilmaz.
        }
    }
}

struct Personel { // personele info eklemeleri yapilir.
    //name-string, age : int, maritalStatus - Bool, type - int
    var name : String
    var age : Int
    var maritalStatus : Bool
    var type : Int

    init(name : String, age : Int, maritalStatus : Bool, type : Int) {
        self.name = name
        self.age = age
        self.maritalStatus = maritalStatus
        self.type = type
    }
}

var company = Company(personel: employees, salaries: salaries, salarySum: sum) // sirket olusturuldu

var myPers = Personel(name: "cumali", age: 25, maritalStatus: true, type: 2)
employees.append(myPers.name) // personel listesine eklenir.
salaries.append(myPers.age * myPers.type * 550) // maas hesaplamasi yapilir ve gider listesine eklenir.
company.addPersonel(add: myPers.name) // sirketin pers listesine eklenir

var myPers2 = Personel(name: "nebi", age: 23, maritalStatus: true, type: 3)
employees.append(myPers2.name)
salaries.append(myPers2.age * myPers2.type * 550)
company.addPersonel(add: myPers2.name)

var zipped = Array(zip(employees, salaries)) // calisan ve odeme bilgileri eslestirilir.

for i in salaries {
    sum = sum + i // toplam maas odemesi hesaplanir.
}


company.personel // sirketin personelleri goruntulenebilir.

company.salaryPayment() // sirket maas odemesini yapar.
company.addBudget(forIncrement: 10000) // gelir elde eder.
company.addPayment(pay: 10000) // ek odeme yapar.
company.budget // sirketin son butcesi goruntulenir.


employees.removeLast() // sirketten eleman cikarma
company.disPersonel()
salaries.removeLast()
zipped.removeLast()

company.disPersonel()
salaries.removeLast()
zipped.removeLast()


company.budget

/*
// MARK: HAYVANAT BAHCESI SIMULASYONU

import Foundation

var personels : [String] = [] // hayvanat bahcesi calisanlari
var animals : [String] = [] // hayvanlar
var salaries : [Int] = [] // calisan ucretleri

var sum : Int = 0 // toplam maas bedeli
var sumWater : Int = 0 // gunluk toplam su gideri

protocol Zooable {
    var budget : Int { get set }
    mutating func salaryPayment(salarySum : Int) -> Int
    mutating func addPayment(pay : Int) -> Int
    mutating func addBudget(forIncrement add : Int) -> Int
    
    var waterAmount : Int { get set }
    mutating func addWater(water : Int) -> Int
    mutating func dailyWater(water : Int) -> Int
}

struct Zoo : Zooable {
    
    var budget: Int = 100000 // bahcenin butcesi
    var waterAmount: Int = 10000 // su miktari
    var personel : [String]
    var salaries : [Int]
    var dailyWater : Int
    var salarySum : Int
}

extension Zoo {
    mutating func salaryPayment(salarySum : Int) -> Int { // maas odemeleri
        if salarySum <= budget { // yeterli butce varsa
            budget = budget - salarySum // odemeyi yapar.
            return budget
        } else { // yoksa yapamaz.
            print("yeterli butce bulunmamaktadir")
            return budget
        }
    }
    
    mutating func addPayment(pay: Int) -> Int {
        if pay <= budget { // yeterli butce varsa ek gider odemesini yapar.
            budget = budget - pay
            return budget
        } else { // yoksa yapamaz.
            print("yeterli butce bulunmamaktadir")
        }
        return budget
    }
        
    mutating func addBudget(forIncrement add: Int) -> Int {
            budget += add // ek gelir girisi
            return budget
    }
}

extension Zoo {
    mutating func addWater(water: Int) -> Int {
        waterAmount += water // bahceye su girisi
        return waterAmount
    }

    mutating func dailyWater(water: Int) -> Int {
        waterAmount -= water // hayvanlara su verilince duser.
        return waterAmount
    }
}

protocol Animalable {
    var animalName : String { get set }
    var animalSitter : String { get set } // hayvan bakicisi
    mutating func drinkWater(water : Int) -> Int // gunluk ictigi su
    mutating func animalNoise() // hayvan ses cikarirsa calisir.
}

struct Animal : Animalable {
    var animalName: String
    var animalSitter: String
    
    mutating func drinkWater(water: Int) -> Int{
        print("\(animalName), \(water) litre su icti")
        return water
    }
    
    mutating func animalNoise() {
        print("\(animalName), ses cikardi")
    }
}

protocol PetSitterable {
    var name : String { get set }
    var salary : Int { get set }
}

struct PetSitter : PetSitterable { // bakici
    var name: String
    var salary: Int
    
    init(name : String, salary : Int) {
        self.name = name
        self.salary = salary
    }
}
// bahce olusturuldu.
var zoo = Zoo(personel : personels, salaries : salaries, dailyWater : sumWater, salarySum: sum)

// yeni bakici eklenir.
var petSit = PetSitter(name: "cumali", salary: 1000)
personels.append(petSit.name)
salaries.append(petSit.salary) // bakici maasi, maaslar arrayine eklenir.


var petSit2 = PetSitter(name: "yusuf", salary: 10010)
personels.append(petSit2.name)
salaries.append(petSit2.salary)

var anim = Animal(animalName: "congomongo", animalSitter: "cumali") // hayvan olusturulur, bakici atanir.
animals.append(anim.animalName)
anim.animalNoise() // ses cikarir.
sumWater += anim.drinkWater(water: 10) // hayvan su icer.

var anim2 = Animal(animalName: "congocongo", animalSitter: "yusuf")
animals.append(anim2.animalName)
anim2.animalNoise()
sumWater += anim2.drinkWater(water: 11)

for i in salaries {
    sum += i // maaslar toplanir.
}

zoo.salaryPayment(salarySum: sum) // maas odemesi yapilir.
zoo.addPayment(pay: 1923) // ek gider
zoo.addBudget(forIncrement: 1924) // gelir eklenir.
zoo.addWater(water: 205) // su eklenir
zoo.dailyWater(water: 200) // hayvanlar su icer ve depodan dusulur.
zoo.waterAmount // kalan su miktarı
zoo.budget // kalan bahce butcesi.
*/
